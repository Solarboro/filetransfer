package org.solar.controller;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatus.Series;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ThrowErrorHandler extends DefaultResponseErrorHandler {

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException{
		return super.hasError(response);
	}
	
	@Override
	public void handleError(ClientHttpResponse response) throws IOException{

//		if (response.getStatusCode().series() == Series.SERVER_ERROR){
//			byte [] resBody = new byte[response.getBody().available()];
//			response.getBody().read(resBody);
//			System.out.println("Error: " + new String(resBody));
//			
//		}
		super.handleError(response);
	
	}
}
