/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RmtInf {

    private String paymentDetails;
    private List<InvoiceDetails> invoiceDetails;
    private List<ClientReferences> clientReferences;
    public void setPaymentDetails(String paymentDetails) {
         this.paymentDetails = paymentDetails;
     }
     public String getPaymentDetails() {
         return paymentDetails;
     }

    public void setInvoiceDetails(List<InvoiceDetails> invoiceDetails) {
         this.invoiceDetails = invoiceDetails;
     }
     public List<InvoiceDetails> getInvoiceDetails() {
         return invoiceDetails;
     }

    public void setClientReferences(List<ClientReferences> clientReferences) {
         this.clientReferences = clientReferences;
     }
     public List<ClientReferences> getClientReferences() {
         return clientReferences;
     }

}