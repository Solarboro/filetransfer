/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.res;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Auto-generated: 2018-10-15 14:57:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TxnResponse {

    private String customerReference;
    private String txnRefId;
    private String bankReference;
    private String txnType;
    private String txnStatus;
    private String txnRejectCode;
    private String txnStatusDescription;
    private String txnSettlementAmt;
    private String txnSettlementDt;
    public void setCustomerReference(String customerReference) {
         this.customerReference = customerReference;
     }
     public String getCustomerReference() {
         return customerReference;
     }

    public void setTxnRefId(String txnRefId) {
         this.txnRefId = txnRefId;
     }
     public String getTxnRefId() {
         return txnRefId;
     }

    public void setBankReference(String bankReference) {
         this.bankReference = bankReference;
     }
     public String getBankReference() {
         return bankReference;
     }

    public void setTxnType(String txnType) {
         this.txnType = txnType;
     }
     public String getTxnType() {
         return txnType;
     }

    public void setTxnStatus(String txnStatus) {
         this.txnStatus = txnStatus;
     }
     public String getTxnStatus() {
         return txnStatus;
     }

    public void setTxnRejectCode(String txnRejectCode) {
         this.txnRejectCode = txnRejectCode;
     }
     public String getTxnRejectCode() {
         return txnRejectCode;
     }

    public void setTxnStatusDescription(String txnStatusDescription) {
         this.txnStatusDescription = txnStatusDescription;
     }
     public String getTxnStatusDescription() {
         return txnStatusDescription;
     }

    public void setTxnSettlementAmt(String txnSettlementAmt) {
         this.txnSettlementAmt = txnSettlementAmt;
     }
     public String getTxnSettlementAmt() {
         return txnSettlementAmt;
     }

    public void setTxnSettlementDt(String txnSettlementDt) {
         this.txnSettlementDt = txnSettlementDt;
     }
     public String getTxnSettlementDt() {
         return txnSettlementDt;
     }

}