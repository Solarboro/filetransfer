/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.valid.res;

/**
 * Auto-generated: 2018-10-15 14:53:59
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ValidRes {

    private Header header;
    private EnqResponse enqResponse;
    public void setHeader(Header header) {
         this.header = header;
     }
     public Header getHeader() {
         return header;
     }

    public void setEnqResponse(EnqResponse enqResponse) {
         this.enqResponse = enqResponse;
     }
     public EnqResponse getEnqResponse() {
         return enqResponse;
     }

}