/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdviseDelivery {

    private String mode;
    private List<Emails> emails;
    private List<PhoneNumbers> phoneNumbers;
    public void setMode(String mode) {
         this.mode = mode;
     }
     public String getMode() {
         return mode;
     }

    public void setEmails(List<Emails> emails) {
         this.emails = emails;
     }
     public List<Emails> getEmails() {
         return emails;
     }

    public void setPhoneNumbers(List<PhoneNumbers> phoneNumbers) {
         this.phoneNumbers = phoneNumbers;
     }
     public List<PhoneNumbers> getPhoneNumbers() {
         return phoneNumbers;
     }

}