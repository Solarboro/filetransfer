/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.valid.res;

/**
 * Auto-generated: 2018-10-15 14:53:59
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class EnqResponse {

    private String txnRefId;
    private String proxyType;
    private String proxyValue;
    private String respStatus;
    private String respStatusDescription;
    private String respRejectCode;
    private String accountName;
    private String dispNameEn;
    private String dispNameZh;
    public void setTxnRefId(String txnRefId) {
         this.txnRefId = txnRefId;
     }
     public String getTxnRefId() {
         return txnRefId;
     }

    public void setProxyType(String proxyType) {
         this.proxyType = proxyType;
     }
     public String getProxyType() {
         return proxyType;
     }

    public void setProxyValue(String proxyValue) {
         this.proxyValue = proxyValue;
     }
     public String getProxyValue() {
         return proxyValue;
     }

    public void setRespStatus(String respStatus) {
         this.respStatus = respStatus;
     }
     public String getRespStatus() {
         return respStatus;
     }

    public void setRespStatusDescription(String respStatusDescription) {
         this.respStatusDescription = respStatusDescription;
     }
     public String getRespStatusDescription() {
         return respStatusDescription;
     }

    public void setRespRejectCode(String respRejectCode) {
         this.respRejectCode = respRejectCode;
     }
     public String getRespRejectCode() {
         return respRejectCode;
     }

    public void setAccountName(String accountName) {
         this.accountName = accountName;
     }
     public String getAccountName() {
         return accountName;
     }

    public void setDispNameEn(String dispNameEn) {
         this.dispNameEn = dispNameEn;
     }
     public String getDispNameEn() {
         return dispNameEn;
     }

    public void setDispNameZh(String dispNameZh) {
         this.dispNameZh = dispNameZh;
     }
     public String getDispNameZh() {
         return dispNameZh;
     }

}