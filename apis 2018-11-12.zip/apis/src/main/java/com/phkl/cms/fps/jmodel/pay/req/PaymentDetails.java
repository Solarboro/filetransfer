/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Auto-generated: 2018-10-07 15:43:53
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentDetails {

    private String paymentDetail;
    public void setPaymentDetail(String paymentDetail) {
         this.paymentDetail = paymentDetail;
     }
     public String getPaymentDetail() {
         return paymentDetail;
     }

}