package com.acn.masg.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		//
		http
		.cors()
		.and()
		.csrf().disable()
		.authorizeRequests()
//        .antMatchers(HttpMethod.POST, "/users/signup").permitAll()
        .anyRequest().authenticated()
        .and()
        .addFilter(new JWTLoginFilter(authenticationManager()))
        .addFilter(new JwtAuthenticationFilter(authenticationManager()));
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// inMemory Auth
		
		auth
		.inMemoryAuthentication()
		.passwordEncoder(
				new PasswordEncoder() {

					@Override
					public String encode(CharSequence rawPassword) {
						// TODO Auto-generated method stub
						return null;
					}

					@Override
					public boolean matches(CharSequence rawPassword, String encodedPassword) {
						// TODO Auto-generated method stub
						return encodedPassword.equals(rawPassword.toString());
					}
			
				}
				)
		.withUser("Solar")
		.password("abcd1234")
		.roles("USER")
		;
	}

	
	
}
