package com.acn.masg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleSecurityApplication.class, args);
	}

}

