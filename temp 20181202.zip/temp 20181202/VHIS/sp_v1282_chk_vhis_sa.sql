{
#######################################################################
   MODULE      : sp_v1282_chk_vhis_sa
   DESCRIPTION : 
   INPUT       : 1) fi_pol_no - policy Number / Proposal Number
                 2) fi_mvmt_no - movement Number
                 3) fi_job_no - Job Number
                 4) fi_mode - PROP: Proposal, Pol: Policy, MVMT: Movement
                 5) fi_prod_cd - product code / benefit code
                 6) fi_trace_log_pflag - P: Enable trace log, others: disable trace log
                 
   OUTPUT      : 1) exec_sta - validation result, 1: true(success) 0: false(fail/Exception)
                 2) excp_flag - Exception flag, Y: Occur exception, N: No Exception
                 3) excp_cd - Exception Code
                 4) remark - to valid_err_msg.remark 
                 5) dyn_msg - to valid_dynamic_msg.dynamic_msg
   Ver Auth.     Date         MCN          Description
   000 Frank PQL 09/11/2018   180603100    Program Creation
#######################################################################
}
drop procedure sp_v1282_chk_vhis_sa;

create procedure "informix".sp_v1282_chk_vhis_sa (
    fi_pol_no       char(12),
    fi_mvmt_no      smallint,
    fi_job_no       smallint,
    fi_mode         char(4),
    fi_prod_cd      char(8),
    fi_trace_log_pflag char(1)
) returning 
    smallint as exec_sta,
    smallint as excp_cd,
    char(70) as excp_rmk,
    char(40) as remark,         --valid_err_msg.remark
    char(300) as dyn_msg        --valid_dynamic_msg.dynamic_msg
    ;
    
    --[Variable Definition]
    --[return variable]
    define fo_exec_sta like valid_hub_log.exec_sta;
    define fo_excp_cd like valid_hub_log.excp_cd;
    define fo_excp_rmk like valid_hub_log.excp_rmk;
    define fo_remark like valid_err_msg.remark;
    define fo_dyn_msg like valid_dynamic_msg.dynamic_msg;
    
    --[local variable - for exception]
    define exp_sql int;
    define exp_isam int;
    define exp_errinfo char(70);
    
    --[local variable for ]
    --put your variable definition here
    define f_exec_flag char(1);
    
    define f_basic_sa like prop_basic.basic_sa;
    define f_ccy like prop_basic.ccy;
    
    define F_SA_USD like prop_basic.basic_sa;
    define F_SA_HKD like prop_basic.basic_sa;
    
    define F_CCY_USD like prop_basic.ccy;
    define F_CCY_HKD like prop_basic.ccy;

    --[Exception Handler]
    --Mandatory
    on exception set exp_sql, exp_isam, exp_errinfo
        --Mandatory, must throw this exception code.
        return 0, exp_sql, exp_errinfo, null, null;
    end exception

    --do not put your code here

    --[Debug log handler]
    if fi_trace_log_pflag = "Y" then
        set debug file to "/tmp/sp_v1282_chk_vhis_sa.log";
        trace on;
    end if
    
    --[Initialize]
    let fo_exec_sta = 0;
    let fo_excp_cd = null;
    let fo_excp_rmk = null;
    let fo_remark = fi_prod_cd;
    let fo_dyn_msg = null;
    let f_exec_flag = "Y";
    
    let f_basic_sa = null;
    let f_ccy = null;
    
    let F_SA_USD = 1000;
    let F_SA_HKD = 7750;
    
    let F_CCY_USD = "USD";
    let F_CCY_HKD = "HKD";

    --[Proposal Stage]
    if fi_mode = "PROP" then
        select basic_sa,
               ccy
          into f_basic_sa,
               f_ccy
          from prop_basic
         where prop_no = fi_pol_no
           and prod_cd = fi_prod_cd
        ;
    end if
    
    --[Policy Stage]
    if fi_mode = "POL" then
        select basic_sa,
               ccy
          into f_basic_sa,
               f_ccy
          from pol_basic
         where pol_no = fi_pol_no
           and prod_cd = fi_prod_cd
        ;
    end if

    --[Movement Stage]
    if fi_mode = "MVMT" then
        select basic_sa,
               ccy
          into f_basic_sa,
               f_ccy
          from mvmt_pol_basic
         where pol_no = fi_pol_no
           and prod_cd = fi_prod_cd
           and job_no = fi_job_no
         ;
    end if
    
    --[validation]
    if f_basic_sa is null then
        raise exception 0, 0, "basic sa is null";
    end if
    
    if f_ccy is null then
        raise exception 0, 0, "ccy is null";
    end if

    --[Execution logic 1]
    if f_exec_flag = "Y" then
        --[]
        let f_exec_flag = "N";

        --[VSP, HKD, 7750]
        if fi_prod_cd = "VSP" and
           f_ccy = F_CCY_HKD and
           f_basic_sa = F_SA_HKD then

            let f_exec_flag = "Y";
        end if

        --[VFP, HKD, 7750]
        if fi_prod_cd = "VFP" and
           f_ccy = F_CCY_HKD and
           f_basic_sa = F_SA_HKD then

            let f_exec_flag = "Y";
        end if

        --[VFP, USD, 1000]
        if fi_prod_cd = "VFP" and
           f_ccy = F_CCY_USD and
           f_basic_sa = F_SA_USD then

            let f_exec_flag = "Y";
        end if
        
    end if

    --[Excection check final result]
    if f_exec_flag = "Y" then
        let fo_exec_sta = 1;
        let fo_remark = null;
        let fo_dyn_msg = null;
    end if
    
    --[Return]
    return fo_exec_sta, fo_excp_cd, fo_excp_rmk, fo_remark, fo_dyn_msg;
    
end procedure;
update statistics for procedure "informix".sp_v1282_chk_vhis_sa;
