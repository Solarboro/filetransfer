{
#######################################################################
   MODULE      : sp_valid_hub_boot
   DESCRIPTION : 
   INPUT       : 1) fi_pol_no - policy Number / Proposal Number
                 2) fi_mvmt_no - movement Number
                 3) fi_job_no - Job Number
                 4) fi_chk_level - P: policy Level, B: benefit Level
                 5) fi_mode - PROP: Proposal, Pol: Policy, MVMT: Movement
                 6) fi_prog_id - program Id
                 7) fi_prod_cd - product code / benefit code
                 8) fi_factor - extra factor for extra Rule
                 
   OUTPUT      : 1) exec_sta - execution result, 1: true(success) 0: false(fail/Exception)
  
   Ver Auth.     Date         MCN          Description
   000 Frank PQL 09/11/2018   180603100    Program Creation
#######################################################################
}
drop procedure sp_valid_hub_boot;

create procedure "informix".sp_valid_hub_boot (
    fi_pol_no       char(12),           --Mandatory
    fi_mvmt_no      smallint,           --Mandatory
    fi_job_no       smallint,           --Mandatory
    fi_mode         char(4),            --Mandatory
    fi_chk_level    char(1),            --Mandatory
    fi_prog_id      char(30),           --Mandatory
    fi_prod_cd      char(8),            --Mandatory
    fi_factor       char(10)            --Optional
) returning 
    char(1) as exec_sta;
    
    --local variable
    define f_valid_rule_no smallint;
    define f_exec_sta smallint;
    define f_excp_cd smallint;
    define f_excp_rmk char(70);
    define f_is_dynamic like valid_hub_map_sp.is_dynamic;
    define f_remark like valid_err_msg.remark; 
    define f_dynamic_msg like valid_dynamic_msg.dynamic_msg;

    --exception handler
    on exception        
        return 0;
    end exception
    --initialize
    
    --Runnable Validation
    if fi_pol_no is null or
       fi_pol_no = " " then
        raise exception 0, 0, "Madatory Param: Prop/Pol No. is missing";
    end if
    
    if fi_mvmt_no is null then
        raise exception 0, 0, "Madatory Param: Movement No. is missing";
    end if
    
    --Clean up valid_err_msg
    delete from valid_err_msg
     where prop_pol_no = fi_pol_no
       and mvmt_no = fi_mvmt_no
       and valid_rule_no in ( select valid_rule_no 
                                from valid_hub_map_main );
    
    --Clean up Write-Back Table
    delete from valid_dynamic_msg
     where prop_pol_no = fi_pol_no
       and mvmt_no = fi_mvmt_no
       and valid_rule_no in ( select valid_rule_no 
                                from valid_hub_map_main );
                                
    foreach
        execute procedure sp_valid_hub(fi_pol_no,
                                       fi_mvmt_no,
                                       fi_job_no,
                                       fi_mode,
                                       fi_chk_level,
                                       fi_prog_id,
                                       fi_prod_cd,
                                       fi_factor
                                       ) 
                     into f_valid_rule_no,
                          f_exec_sta,
                          f_excp_cd,
                          f_excp_rmk

        --Validation Fail/Exception, update into error message table.
        if f_exec_sta = 0 then
        
            --Initialized
            let f_remark = "";
            let f_dynamic_msg = "";
            let f_is_dynamic = "";
            
            --[valid_err_msg.remark]
            --Get Valid error remark
            select para_value
              into f_remark
              from valid_hub_stg
             where pol_no = fi_pol_no
               and prog_id = fi_prog_id
               and valid_rule_no = f_valid_rule_no
               and para_key = "VAL_ERR_RMK";

            --Update into valid_err_msg
            insert into valid_err_msg values(fi_pol_no, fi_mvmt_no, f_remark, f_valid_rule_no);
            
            --[valid_dynamic_msg.dynamic_msg]
            --Get Dynamic Message
            select para_value
              into f_dynamic_msg
              from valid_hub_stg
             where pol_no = fi_pol_no
               and prog_id = fi_prog_id
               and valid_rule_no = f_valid_rule_no
               and para_key = "VAL_DYN_MSG";
               
            --Get Dynamic Flag
            select is_dynamic
              into f_is_dynamic
              from valid_hub_map_sp
             where valid_rule_no = f_valid_rule_no
               and chk_level = fi_chk_level;
               
            --Update into valid_daynamic_msg
            if f_dynamic_msg is not null and 
               f_dynamic_msg <> " " and
               f_is_dynamic = "Y" then
                insert into valid_dynamic_msg values(fi_pol_no, fi_mvmt_no, f_dynamic_msg, f_valid_rule_no);
            end if
            
        end if
        
    end foreach
    
    --
    return 1;
    
end procedure;
update statistics for procedure "informix".sp_valid_hub_boot;