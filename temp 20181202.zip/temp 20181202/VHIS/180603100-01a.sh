#!/bin/ksh
###########################################################################################
#<180603100-01a.sh>
# Description    :
#                  1.Drop and create stored procedure sp_valid_hub.sql
#
# Usage          : 180603100-01a.sh prulifed1 develop
#
# VER  DATE          AUTH       MCN              DESCRIPTION
# 000  09/11/2018    Frank  180603100-01         Program Creation
##########################################################################################

if [ $# -lt 2 ]
then
    echo "Invalid parameters!"
    echo "Usage: $0 <db server> <data path>"
    exit 1
fi

INFORMIXSERVER=$1
SPATH=$2
CTLNO=`echo $0|awk -F'/' '{print $NF}'|cut -f1 -d'.'`
LOGFILE=/prulife/tmp/${INFORMIXSERVER}/${CTLNO}.log
CHKPATH=/develop/life/log/
CURPATH=/$SPATH
export INFORMIXSERVER SPATH LOGFILE CHKPATH CURPATH

echo "$CTLNO.sh" > ${LOGFILE}
hostname >> ${LOGFILE}
echo "INFORMIXSERVER = $1 " >> ${LOGFILE}
echo "CURPATH        = ${CURPATH}" >> ${LOGFILE}
echo "LOGFILE        = ${CHKPATH}" >> ${LOGFILE}
echo "Production Control: ${CTLNO}" >> ${LOGFILE}

date >> ${LOGFILE}

echo "==================== Begin  process ========================" >> ${LOGFILE}
(
isql -s prulife <<!EOF

set lock mode to wait;

!echo "##################### 1.sp_valid_hub.sql #####################"
!echo "---------- Before image: sp_valid_hub.sql ----------"
!dbschema -d prulife -f "informix".sp_valid_hub ;

!echo "---------- Update sp: sp_valid_hub.sql ----------"
!dbaccess prulife /$SPATH/life/store/sp_valid_hub.sql ;

!echo "---------- After  image: sp_valid_hub.sql ----------"
!dbschema -d prulife -f "informix".sp_valid_hub ;

!echo "##################### 2.sp_valid_hub_boot.sql #####################"
!echo "---------- Before image: sp_valid_hub_boot.sql ----------"
!dbschema -d prulife -f "informix".sp_valid_hub_boot ;

!echo "---------- Update sp: sp_valid_hub_boot.sql ----------"
!dbaccess prulife /$SPATH/life/store/sp_valid_hub_boot.sql ;

!echo "---------- After  image: sp_valid_hub_boot.sql ----------"
!dbschema -d prulife -f "informix".sp_valid_hub_boot ;

!EOF
) >> ${LOGFILE} 2>&1

echo "==================== Complete  process =====================" >> ${LOGFILE}

date >> ${LOGFILE}

chmod 666 ${LOGFILE}

cp -p ${LOGFILE} ${CHKPATH}
