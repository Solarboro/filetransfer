{
#######################################################################
   MODULE      : sp_v1288_chk_hkid_hkresid
   DESCRIPTION : 
   INPUT       : 1) fi_pol_no - policy Number / Proposal Number
                 2) fi_mvmt_no - movement Number
                 3) fi_job_no - Job Number
                 4) fi_mode - PROP: Proposal, Pol: Policy, MVMT: Movement
                 5) fi_prod_cd - product code / benefit code
                 6) fi_trace_log_pflag - P: Enable trace log, others: disable trace log
                 
   OUTPUT      : 1) exec_sta - validation result, 1: true(success) 0: false(fail/Exception)
                 2) excp_flag - Exception flag, Y: Occur exception, N: No Exception
                 3) excp_cd - Exception Code
                 4) remark - to valid_err_msg.remark 
                 5) dyn_msg - to valid_dynamic_msg.dynamic_msg
   Ver Auth.     Date         MCN          Description
   000 Frank PQL 09/11/2018   180603100    Program Creation
#######################################################################
}
drop procedure sp_v1288_chk_hkid_hkresid;

create procedure "informix".sp_v1288_chk_hkid_hkresid (
    fi_pol_no       char(12),           --Mandatory
    fi_mvmt_no      smallint,           --Mandatory
    fi_job_no       smallint,           --Optional
    fi_mode         char(4),            --Mandatory
    fi_prod_cd      char(8),            --Optional
    fi_trace_log_pflag char(1)           --Optional
) returning 
    smallint as exec_sta,
    smallint as excp_cd,
    char(70) as excp_rmk,
    char(40) as remark,         --valid_err_msg.remark
    char(300) as dyn_msg        --valid_dynamic_msg.dynamic_msg
    ;
    --return variable
    define fo_exec_sta like valid_hub_log.exec_sta;
    define fo_excp_cd like valid_hub_log.excp_cd;
    define fo_excp_rmk like valid_hub_log.remark;
    define fo_remark like valid_err_msg.remark;
    define fo_dyn_msg like valid_dynamic_msg.dynamic_msg;
    
    --local variable: for exception
    define exp_sql int;
    define exp_isam int;
    define exp_errinfo char(70);
    
    --local variable: for []
    --put your variable definition here
    define f_exec_flag char(1);
    define f_err_cd char(4);
    define f_rtn_val smallint;
    define f_pol_sta like prop_basic.pol_sta;
    define f_incpt_dt like prop_basic.incpt_dt;
    define f_client_cd like cdb_mast.client_cd;
    define f_dob like cdb_mast.dob;
    define f_anb integer;
    define f_ctry_cd like cdb_address.country_cd;
    
    --exception handler
    --Mandatory
    on exception set exp_sql, exp_isam, exp_errinfo
        --Mandatory, must throw this exception code.
        return 0, exp_sql, exp_errinfo, null, null;
    end exception

    --do not put your code here
    
    --Debug log handler
    if fi_trace_log_pflag = "P" then
        set debug file to "/tmp/sp_v1288_chk_hkid_hkresid.log";
        trace on;
    end if
    
    --Initialize
    let fo_exec_sta = 0;
    let fo_excp_cd = null;
    let fo_excp_rmk = null;
    let fo_remark = null;
    let fo_dyn_msg = null;
    
    let f_exec_flag = "Y";
    let f_client_cd = null;
    let f_incpt_dt = null;
    let f_dob = null;
    let f_anb = null;
    let f_ctry_cd = null;
    
    --Get get client code, dob, inception date
    if fi_mode = "PROP" then
        --get client code, dob
        select cm.client_cd, cm.dob
          into f_client_cd, f_dob
          from prop_person_hdr pph, cdb_mast cm
         where pph.prop_no = fi_pol_no
           and pph.client_role = "L"
           and pph.client_cd = cm.client_cd;
           
        --get inception date
        select incpt_dt
          into f_incpt_dt
          from prop_basic
         where prop_no = fi_pol_no;
    end if
    
    if fi_mode = "POL" then
        --get client code, dob
        select cm.client_cd, cm.dob
          into f_client_cd, f_dob
          from pol_person_hdr pph, cdb_mast cm
         where pph.pol_no = fi_pol_no
           and pph.client_role = "L"
           and pph.client_cd = cm.client_cd;
      
        --get inception date
        select incpt_dt
          into f_incpt_dt
          from pol_basic
         where pol_no = fi_pol_no;
    end if
    
    --valid dob
    if f_dob is null then
        raise exception 0, 0, "Incorrect DOB Value";
    end if
    
    --valid incpt dt
    if f_incpt_dt is null then
        raise exception 0, 0, "Incorrect Inception Date";
    end if
    
    --Excection 1 - calc ANB 
    if f_exec_flag = "Y" then
        let f_anb = cal_anb(f_dob, f_incpt_dt);
        
        --Valid HK Residential, if ANB Under 12
        if f_anb < 12 then
            select ca.country_cd
              into f_ctry_cd
              from cdb_address ca
             where ca.client_cd = f_client_cd
               and ca.type = "R";
               
            --Validation Fail
            if f_ctry_cd <> "H" Then
                let f_exec_flag = "N";
            end if
        end if
    end if
    
    --Excection 2 - valid HKID Card Holder
    if f_exec_flag = "Y" then
        execute procedure sp_chk_propol_hkid(fi_pol_no, 3, fi_mode) into f_err_cd, f_rtn_val;
        
        --Validation Success
        if f_rtn_val <> 1 then
            let f_exec_flag = "N";
        end if
    end if;
    
    --Excection Final - check status
    if f_exec_flag = "Y" then
        let fo_exec_sta = 1;
    end if
    
    --Default Validation fail
    return fo_exec_sta, fo_excp_cd, fo_excp_rmk, fo_remark, fo_dyn_msg;
    
end procedure;
update statistics for procedure "informix".sp_v1288_chk_hkid_hkresid;
