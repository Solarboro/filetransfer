{
#######################################################################
   MODULE      : sp_v1286_chk_vfp_benf_opt
   DESCRIPTION : 
   INPUT       : 1) fi_pol_no - policy Number / Proposal Number
                 2) fi_mvmt_no - movement Number
                 3) fi_job_no - Job Number
                 4) fi_mode - PROP: Proposal, Pol: Policy, MVMT: Movement
                 5) fi_prod_cd - product code / benefit code
                 6) fi_trace_log_pflag - P: Enable trace log, others: disable trace log
                 
   OUTPUT      : 1) exec_sta - validation result, 1: true(success) 0: false(fail/Exception)
                 2) excp_flag - Exception flag, Y: Occur exception, N: No Exception
                 3) excp_cd - Exception Code
                 4) remark - to valid_err_msg.remark 
                 5) dyn_msg - to valid_dynamic_msg.dynamic_msg
   Ver Auth.     Date         MCN          Description
   000 Frank PQL 09/11/2018   180603100    Program Creation
#######################################################################
}
drop procedure sp_v1286_chk_vfp_benf_opt;

create procedure "informix".sp_v1286_chk_vfp_benf_opt (
    fi_pol_no       char(12),           --Mandatory
    fi_mvmt_no      smallint,           --Mandatory
    fi_job_no       smallint,           --Optional
    fi_mode         char(4),            --Mandatory
    fi_prod_cd      char(8),            --Optional
    fi_trace_log_pflag char(1)           --Optional
) returning 
    smallint as exec_sta,
    smallint as excp_cd,
    char(70) as excp_rmk,
    char(40) as remark,         --valid_err_msg.remark
    char(300) as dyn_msg        --valid_dynamic_msg.dynamic_msg
    ;
    
    --return variable
    define fo_exec_sta like valid_hub_log.exec_sta;
    define fo_excp_cd like valid_hub_log.excp_cd;
    define fo_excp_rmk like valid_hub_log.remark;
    define fo_remark like valid_err_msg.remark;
    define fo_dyn_msg like valid_dynamic_msg.dynamic_msg;
    
    --local variable: for exception
    define exp_sql int;
    define exp_isam int;
    define exp_errinfo char(70);
    
    --local variable: for []
    --put your variable definition here
    define f_exec_flag char(1);
    define f_pol_sta like prop_basic.pol_sta;
    define f_benf_opt_cd1 like prop_benf.benf_opt_cd1;
    define f_benf_opt_cd2 like prop_benf.benf_opt_cd2;
    
    --exception handler
    --Mandatory
    on exception set exp_sql, exp_isam, exp_errinfo
        --Mandatory, must throw this exception code.
        return 0, exp_sql, exp_errinfo, null, null;
    end exception

    --do not put your code here
    
    --Debug log handler
    if fi_trace_log_pflag = "P" then
        set debug file to "/tmp/sp_v1286_chk_vfp_benf_opt.log";
        trace on;
    end if
    
    --Initialize
    let fo_exec_sta = 0;
    let fo_excp_cd = null;
    let fo_excp_rmk = null;
    let fo_remark = null;
    let fo_dyn_msg = null;
    
    let f_exec_flag = "Y";   
    let f_pol_sta = null;
    let f_benf_opt_cd1 = null;
    let f_benf_opt_cd2 = null;
    
    --[proposal level] get benefit option 1 and option 2
    if fi_mode = "PROP" then
        select benf_opt_cd1,
               benf_opt_cd2
          into f_benf_opt_cd1,
               f_benf_opt_cd2
          from prop_benf
         where prop_no = fi_pol_no
           and benf_cd = fi_prod_cd
           and benf_cd in ( select benf_cd
                              from benf_mast
                             where master_benf_cd in ("VFP", "VFPR")
                           );
    end if

    --[policy level] get benefit option 1 and option 2
    if fi_mode = "POL" then
        select benf_opt_cd1,
               benf_opt_cd2
          into f_benf_opt_cd1,
               f_benf_opt_cd2
          from pol_benf
         where pol_no = fi_pol_no
           and benf_cd = fi_prod_cd
           and benf_cd in ( select benf_cd
                              from benf_mast
                             where master_benf_cd in ("VFP", "VFPR")
                           );
    end if
    
    --[movement level] get benefit option 1 and option 2
    if fi_mode = "MVMT" then
        select benf_opt_cd1,
               benf_opt_cd2
          into f_benf_opt_cd1,
               f_benf_opt_cd2
          from mvmt_pol_benf
         where pol_no = fi_pol_no
           and job_no = fi_job_no
           and benf_cd = fi_prod_cd
           and benf_cd in ( select benf_cd
                              from benf_mast
                             where master_benf_cd in ("VFP", "VFPR")
                           );
    end if
    

    --valid on option1
    --skip for the case
    --1. without VFP/VFPR 
    --2. without benefit option
    if f_benf_opt_cd1 is null or
       f_benf_opt_cd1 = " " then
       --
       return 1, null, null, null, null;
    end if
    
    --valid on option2
    --skip for the case
    --1. without VFP/VFPR 
    --2. without benefit option
    if f_benf_opt_cd2 is null or
       f_benf_opt_cd2 = " " then
       --
       return 1, null, null, null, null;
    end if

    --Excection 1 - check is the benefit option eligible
    if f_exec_flag = "Y" then
    
        --For Room Level with Private (P, SP)
        if f_benf_opt_cd1 = "P" or
           f_benf_opt_cd1 = "SP" then
           
            --only Apply for N/Option 1 under with SMM option
            if f_benf_opt_cd2 <> "N" and
               f_benf_opt_cd2 <> "Option 1" then
            
               let f_exec_flag = "N";
            end if
        end if        
    end if
    
    --Excection Final - check status
    if f_exec_flag = "Y" then
        let fo_exec_sta = 1;
    end if
    
    --Default Reutrn false
    return fo_exec_sta, fo_excp_cd, fo_excp_rmk, fo_remark, fo_dyn_msg;
    
end procedure;
update statistics for procedure "informix".sp_v1286_chk_vfp_benf_opt;
