{
#######################################################################
   MODULE      : sp_valid_hub
   DESCRIPTION : 
   INPUT       : 1) fi_pol_no - policy Number / Proposal Number
                 2) fi_mvmt_no - movement Number, save to valid_err_msg.mvmt_no
                 3) fi_job_no - Job Number
                 4) fi_chk_level - P: policy Level, B: benefit Level
                 5) fi_mode - PROP: Proposal, Pol: Policy, MVMT: Movement
                 6) fi_prog_id - program Id
                 7) fi_prod_cd - product code / benefit code
                 8) fi_factor - extra factor for extra Rule
                 
   OUTPUT      : 1) valid_rule_no - return Validation Rule Number
                 2) exec_sta - validation result, 1: true(success) 0: false(fail/Exception)
                 3) excp_flag - Exception flag, Y: Occur exception, N: No Exception
                 4) excp_cd - Exception Code
  
   Ver Auth.     Date         MCN          Description
   000 Frank PQL 09/11/2018   180603100    Program Creation
#######################################################################
}
drop procedure sp_valid_hub;

create procedure "informix".sp_valid_hub (
    fi_pol_no       char(12),           --Mandatory
    fi_mvmt_no      smallint,           --Mandatory
    fi_job_no       smallint,           --Mandatory
    fi_mode         char(4),            --Mandatory
    fi_chk_level    char(1),            --Mandatory
    fi_prog_id      char(30),           --Mandatory
    fi_prod_cd      char(8),            --Mandatory
    fi_factor       char(10)            --Optional
) returning 

    smallint as valid_rule_no,
    smallint as exec_sta,
    smallint as excp_cd,
    char(70) as excp_rmk
    ;

    --return variable
    define fo_valid_rule_no like valid_hub_log.valid_rule_no;
    define fo_exec_sta like valid_hub_log.exec_sta;
    define fo_excp_cd like valid_hub_log.excp_cd;
    define fo_excp_rmk like valid_hub_log.excp_rmk;
    
    --local variable: Exception
    define exp_sql int;
    define exp_isam int;
    define exp_errinfo char(70);
    
    --local variable: normal
    define f_sp_stmt char(500);
    define f_sp like valid_hub_map_sp.sp;
    define f_trace_log_pflag like valid_hub_map_sp.trace_log_pflag;
    define f_is_dynamic like valid_hub_map_sp.is_dynamic;
    define f_remark like valid_err_msg.remark;
    define f_dyn_msg like valid_dynamic_msg.dynamic_msg;
    
    define f_valid_rule_no like valid_hub_map_main.valid_rule_no;
    define f_prog_id like valid_hub_map_main.extra_rule_by_prog_id;
    define f_prod_cd like valid_hub_map_main.extra_rule_by_prod_cd;
    define f_factor like valid_hub_map_main.extra_rule_by_factor;
    
   
   --exception handler
    on exception set exp_sql, exp_isam, exp_errinfo
        --VHUB Exception
        insert into valid_hub_log
        values ("0",
                "0",
                "0",
                "0",
                "0",
                "VHUB",
                "",
                "",
                fo_valid_rule_no,
                0,
                exp_sql,
                exp_errinfo,
                current, fn_userid());
        
        return fo_valid_rule_no, 0, exp_sql, exp_errinfo;
    end exception
    
    --lock
    set lock mode to wait;
    
    --Test
    set debug file to "debug.log";
    trace on;
    
    --Initialize Variable
    let fo_valid_rule_no = 0;
    let f_remark = "";
    let f_dyn_msg = "";

    --convert string null to a space
    if fi_factor is null then
        let fi_factor = " ";
    end if
    
    --Runnable Validation
    if fi_pol_no is null or
       fi_pol_no = " " then
        raise exception 0, 0, "Madatory Param: Prop/Pol No. is missing";
    end if
    
    if fi_mvmt_no is null then
        raise exception 0, 0, "Madatory Param: Movement No. is missing";
    end if
    
    if fi_job_no is null then
        raise exception 0, 0, "Madatory Param: Job No. is missing";
    end if
    
    if fi_mode is null or
       fi_mode = " " then
        raise exception 0, 0, "Madatory Param: mode is missing";
    end if
    
    if fi_mode = "PROP" or
       fi_mode = "POL" or
       fi_mode = "MVMT" then
        --valid
    else
        raise exception 0, 0, "Error: Mode doesn't equal to PROP/POL/MVMT";
    end if
       
    if fi_chk_level is null or
       fi_chk_level = " " then
        raise exception 0, 0, "Madatory Param: chk_level is missing";
    end if
    
    if fi_chk_level = "P" or
       fi_chk_level = "B" then
       --valid
    else
       raise exception 0, 0, "Error: Check Level doesn't equal to P/B";
    end if
    
    if fi_prog_id is null or
       fi_prog_id = " " then
        raise exception 0, 0, "Madatory Param: Program ID is missing";
    end if
    
    if fi_prod_cd is null or
       fi_prod_cd = " " then
        raise exception 0, 0, "Madatory Param: Product code is missing";
    end if
    
    --Clean up Write-Back table
    delete from valid_hub_log
     where pol_no = fi_pol_no
       and mvmt_no = fi_mvmt_no
       and job_no = fi_job_no
       and f_mode = fi_mode
       and chk_level = fi_chk_level
       and prog_id = fi_prog_id
       and prod_cd = fi_prod_cd
       and factor = fi_factor;
    
    --Clean up Write-Back table
    --Exception Log
    delete from valid_hub_log
     where pol_no = "0"
       and prog_id = "VHUB";
       
    --Clean up Staging table
    delete from valid_hub_stg
     where pol_no = fi_pol_no
       and prog_id = fi_prog_id;
       
    --Create Temp Table
    create temp table t_eligible_rule(
        valid_rule_no smallint
    ) with no log;
    
    create temp table t_exclude_rule(
        valid_rule_no smallint
    ) with no log;
   
    --[Eligible List, valid_rule_type = Generic]
    --Generic: for all
    insert into t_eligible_rule
    select valid_rule_no
      from valid_hub_map_main
     where valid_rule_type = "Generic";

    --[Eligible List, valid_rule_type = Specify]
    --Specify: Addtional Rule for specify Product Code / Benf Code / factor
    foreach
        select valid_rule_no,
               nvl(extra_rule_by_prog_id, " "),
               nvl(extra_rule_by_prod_cd, " "),
               nvl(extra_rule_by_factor, " ")
          into f_valid_rule_no,
               f_prog_id,
               f_prod_cd,
               f_factor
          from valid_hub_map_main
         where valid_rule_type = "Specify"
           and (
               extra_rule_by_prog_id = fi_prog_id
            or extra_rule_by_prod_cd = fi_prod_cd
            or extra_rule_by_factor = fi_factor
               )

        --validate Program ID
        if f_prog_id <> " " and 
           f_prog_id <> fi_prog_id then
            --not matches with prog id
            continue foreach;
        end if
        
        --validate Prod code
        if f_prod_cd <> " " and 
           f_prod_cd <> fi_prod_cd then
            --not matches with prod_cd
            continue foreach;
        end if
        
        --validate extra factor
        if f_factor <> " " and 
           f_factor <> fi_factor then
            --not matches with extra factor
            continue foreach;
        end if
        
        --current valid rule no is matched, insert into eligible rule
        insert into t_eligible_rule values (f_valid_rule_no);
               
    end foreach

    --[Exclude List, valid_rule_type = Exclude]
    --Exclude: Exclude Rule for specify Product Code / Benf Code / factor
    foreach
        select valid_rule_no,
               nvl(extra_rule_by_prog_id, " "),
               nvl(extra_rule_by_prod_cd, " "),
               nvl(extra_rule_by_factor, " ")
          into f_valid_rule_no,
               f_prog_id,
               f_prod_cd,
               f_factor
          from valid_hub_map_main
         where valid_rule_type = "Exclude"
           and (
               extra_rule_by_prog_id = fi_prog_id
            or extra_rule_by_prod_cd = fi_prod_cd
            or extra_rule_by_factor = fi_factor
               )

        --validate Program ID
        if f_prog_id <> " " and 
           f_prog_id <> fi_prog_id then
            --not matches with prog id
            continue foreach;
        end if
        
        --validate Prod code
        if f_prod_cd <> " " and 
           f_prod_cd <> fi_prod_cd then
            --not matches with prod_cd
            continue foreach;
        end if
        
        --validate extra factor
        if f_factor <> " " and 
           f_factor <> fi_factor then
            --not matches with extra factor
            continue foreach;
        end if
        
        --current valid rule no is matched, insert into exclude rule
        insert into t_exclude_rule values (f_valid_rule_no);
               
    end foreach
    
    --[]
    foreach
        select vhm.valid_rule_no, 
               vhm.sp,
               vhm.trace_log_pflag,
               vhm.is_dynamic
          into fo_valid_rule_no,
               f_sp,
               f_trace_log_pflag,
               f_is_dynamic
          from t_eligible_rule tel,
               valid_hub_map_sp vhm
         where tel.valid_rule_no = vhm.valid_rule_no
           and tel.valid_rule_no not in (select valid_rule_no 
                                           from t_exclude_rule
                                         )
           and vhm.chk_level = fi_chk_level
           and vhm.is_eligible = "Y"
         order by vhm.valid_rule_no
         
        --Initialize in loop
        let f_remark = "";
        let f_dyn_msg = "";

        --prepare stmt and declare stmt
        let f_sp_stmt = "execute procedure " || trim(f_sp) || "(?, ?, ?, ?, ?, ?)";
        prepare proc_stmt from f_sp_stmt;
        declare cur_proc_stmt cursor for proc_stmt;
        open cur_proc_stmt using fi_pol_no,
                                 fi_mvmt_no,
                                 fi_job_no,
                                 fi_mode,
                                 fi_prod_cd,
                                 f_trace_log_pflag;

        --Execute Validation
        fetch cur_proc_stmt into fo_exec_sta,
                                 fo_excp_cd,
                                 fo_excp_rmk,
                                 f_remark,
                                 f_dyn_msg;
        
        --free prepare stmt and declare stmt
        close cur_proc_stmt;
        free cur_proc_stmt;
        free proc_stmt;
        
        --If Faild, update to Write-Back table
        if fo_exec_sta = 0 then
            
            --Fail / Occur Exception
            insert into valid_hub_log
            values (fi_pol_no,
                    fi_mvmt_no,
                    fi_job_no,
                    fi_mode,
                    fi_chk_level,
                    fi_prog_id,
                    fi_prod_cd,
                    fi_factor,
                    fo_valid_rule_no,
                    fo_exec_sta,
                    fo_excp_cd,
                    fo_excp_rmk,
                    current, fn_userid());
            
            --[To Staging]
            --[valid_err_msg.remark]
            --Post Value to staging table for Valid Err Remark
            insert into valid_hub_stg
            values (fi_pol_no, fi_prog_id, fo_valid_rule_no, "VAL_ERR_RMK", f_remark);
            
            --[To Staging]
            --[valid_dynamic_msg.dynamic_msg]
            --Post value to staging table for Dynamic Message
            if f_is_dynamic = "Y" then
                insert into valid_hub_stg 
                values (fi_pol_no, fi_prog_id, fo_valid_rule_no, "VAL_DYN_MSG", f_dyn_msg);
            end if
            
        end if
        
        --[fo_exec_sta] 0: false, 1: true
        --[fo_excp_cd]  null:no Exception, others: occur Exception
        --[fo_excp_rmk] follow [fo_excp_cd]
        return fo_valid_rule_no, fo_exec_sta, fo_excp_cd, fo_excp_rmk with resume;
    end foreach
  
    --Release temp table
    drop table t_eligible_rule;
    drop table t_exclude_rule;
    
end procedure;
update statistics for procedure "informix".sp_valid_hub;
