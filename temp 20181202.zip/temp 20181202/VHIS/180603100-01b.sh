#!/bin/ksh
###############################################################################
#
# 180603100-01b.sh : Create new tables:
#                   1. valid_hub_map_main
#                   2. valid_hub_map_sp
#                   3. valid_hub_log
#                   4. valid_hub_stg
# Usage           : 180603100-01b.sh prulifed1
#
# VER  DATE          AUTH          MCN                  DESCRIPTION
# 000  09/11/2018    Frank         180603100-01         Program Creation 
###############################################################################

if [ $# -lt 1 ]
then
    echo "Not enough input parameters!"
    echo "Usage: $0 <db server>"
    exit 1
fi

CTLNO=`echo $0|awk -F'/' '{print $NF}'|cut -f1 -d'.'`
REQNO=`echo $CTLNO|cut -f1 -d'-'`
JOBNO=`echo $CTLNO|cut -f2 -d'-'`

if [ "X$REQNO" = "X$JOBNO" ]
then
    echo "Invalid IT Request version no.!"
    echo "Usage: $0 <db server>"
    exit 1
fi

typeset -i line_cnt

INFORMIXSERVER=$1
LOGFILE=/prulife/tmp/${INFORMIXSERVER}/${REQNO}-${JOBNO}.log
TMPFILE=/prulife/tmp/${INFORMIXSERVER}/${REQNO}-${JOBNO}.tmp

export LOGFILE INFORMIXSERVER LOGFILE TMPFILE

CHKPATH=/develop/life/log

date > ${LOGFILE}
hostname >> ${LOGFILE}
echo "INFORMIXSERVER = ${INFORMIXSERVER}" >> ${LOGFILE}
echo "${REQNO}-${JOBNO}" >> ${LOGFILE}
echo "Create new tables">> ${LOGFILE}
echo "" >> ${LOGFILE}

echo "-----------------  Begin process  ------------------------" >> ${LOGFILE}
echo "###############  Create new tables: ##################" >> ${LOGFILE}

INDEX_SPACE=`echo "select distinct 'in index1' from sysmaster:sysdbspaces \
           where name = 'index1';" | dbaccess prulife 2>&1|head -8|tail -1`
export INDEX_SPACE


echo "################### 1. valid_hub_map_main  ##################" >> ${LOGFILE}
echo "--------------- Before Image valid_hub_map_main -------------" >> ${LOGFILE}

dbschema -d prulife -t valid_hub_map_main -ss ${TMPFILE} > /dev/null;
cat ${TMPFILE} >> ${LOGFILE}
wc -l ${TMPFILE}|read line_cnt dummy

if [ $line_cnt -gt 7 ]
then
    DROP_TABLE=" drop table valid_hub_map_main ;"
    echo "table valid_hub_map_main will be dropped then re-created" >> ${LOGFILE}
else
    DROP_TABLE=""
    echo "table valid_hub_map_main will be created" >> ${LOGFILE}
fi
echo $DROP_TABLE
echo "--------------- Create table valid_hub_map_main ----------------">> ${LOGFILE}
(
dbaccess prulife <<!EOF

$DROP_TABLE

create table "informix".valid_hub_map_main
(
    valid_rule_no smallint not null,
    valid_rule_type char(10) not null,
    extra_rule_by_prog_id char(30),
    extra_rule_by_prod_cd char(8),
    extra_rule_by_factor char(10),
    excl_rule_by_prog_id char(30),
    excl_rule_by_prod_cd char(8),
    excl_rule_by_factor char(10),
    last_upd_dt datetime year to second,
    last_upd_usr varchar(20)
);

create index "informix".valid_hub_map_main_idx1 on "informix".valid_hub_map_main(valid_rule_type) ${INDEX_SPACE} ;

create index "informix".valid_hub_map_main_idx2 on "informix".valid_hub_map_main(extra_rule_by_prog_id) ${INDEX_SPACE} ;
create index "informix".valid_hub_map_main_idx3 on "informix".valid_hub_map_main(extra_rule_by_prod_cd) ${INDEX_SPACE} ;
create index "informix".valid_hub_map_main_idx4 on "informix".valid_hub_map_main(excl_rule_by_prog_id) ${INDEX_SPACE} ;
create index "informix".valid_hub_map_main_idx5 on "informix".valid_hub_map_main(excl_rule_by_prod_cd) ${INDEX_SPACE} ;

revoke all on "informix".valid_hub_map_main from "public" as "informix";
grant all on "informix".valid_hub_map_main to "prulife_all_access" as "informix";
update statistics for table "informix".valid_hub_map_main;

!EOF
) >>${LOGFILE}  2>&1

echo "------------- After Image valid_hub_map_main------------" >> ${LOGFILE}

dbschema -d prulife -t valid_hub_map_main -ss ${TMPFILE} > /dev/null;
cat ${TMPFILE} >> ${LOGFILE}

echo "################### 2. valid_hub_map_sp  ##################" >> ${LOGFILE}
echo "--------------- Before Image valid_hub_map_sp-------------" >> ${LOGFILE}

dbschema -d prulife -t valid_hub_map_sp -ss ${TMPFILE} > /dev/null;
cat ${TMPFILE} >> ${LOGFILE}
wc -l ${TMPFILE}|read line_cnt dummy

if [ $line_cnt -gt 7 ]
then
    DROP_TABLE=" drop table valid_hub_map_sp ;"
    echo "table valid_hub_map_sp will be dropped then re-created" >> ${LOGFILE}
else
    DROP_TABLE=""
    echo "table valid_hub_map_sp will be created" >> ${LOGFILE}
fi
echo $DROP_TABLE
echo "--------------- Create table valid_hub_map_sp ----------------">> ${LOGFILE}
(
dbaccess prulife <<!EOF

$DROP_TABLE

create table "informix".valid_hub_map_sp
  (
        valid_rule_no smallint not null,
        chk_level char(1) not null,
        is_dynamic char(1) not null,
        sp char(50) not null,
        is_eligible char(1),
        trace_log_pflag char(1),
        last_upd_dt datetime year to second,
        last_upd_usr varchar(20)
  );

create unique index "informix".valid_hub_map_sp_idx1 on "informix".valid_hub_map_sp(valid_rule_no, chk_level) ${INDEX_SPACE} ;

revoke all on "informix".valid_hub_map_sp from "public" as "informix";
grant all on "informix".valid_hub_map_sp to "prulife_all_access" as "informix";
update statistics for table "informix".valid_hub_map_sp;


!EOF
) >>${LOGFILE}  2>&1

echo "------------- After Image valid_hub_map_sp------------" >> ${LOGFILE}

dbschema -d prulife -t valid_hub_map_sp -ss ${TMPFILE} > /dev/null;
cat ${TMPFILE} >> ${LOGFILE}

echo "################### 3. valid_hub_log  ##################" >> ${LOGFILE}
echo "--------------- Before Image valid_hub_log-------------" >> ${LOGFILE}

dbschema -d prulife -t valid_hub_log -ss ${TMPFILE} > /dev/null;
cat ${TMPFILE} >> ${LOGFILE}
wc -l ${TMPFILE}|read line_cnt dummy

if [ $line_cnt -gt 7 ]
then
    DROP_TABLE=" drop table valid_hub_log ;"
    echo "table valid_hub_log will be dropped then re-created" >> ${LOGFILE}
else
    DROP_TABLE=""
    echo "table valid_hub_log will be created" >> ${LOGFILE}
fi
echo $DROP_TABLE
echo "--------------- Create table valid_hub_log ----------------">> ${LOGFILE}
(
dbaccess prulife <<!EOF

$DROP_TABLE

create table "informix".valid_hub_log
  (
        pol_no char(12),
        mvmt_no smallint,
        job_no smallint,
        f_mode char(4),
        chk_level char(1),
        prog_id char(30),
        prod_cd char(8),
        factor char(10),
        valid_rule_no smallint,
        exec_sta smallint ,
        excp_cd smallint,
        excp_rmk char(70),
        last_upd_dt datetime year to second,
        last_upd_usr varchar(20)
  );

create index "informix".valid_hub_log_idx1 on "informix".valid_hub_log(pol_no, prog_id) ${INDEX_SPACE} ;

revoke all on "informix".valid_hub_log from "public" as "informix";
grant all on "informix".valid_hub_log to "prulife_all_access" as "informix";
update statistics for table "informix".valid_hub_log;


!EOF
) >>${LOGFILE}  2>&1

echo "------------- After Image valid_hub_log------------" >> ${LOGFILE}

dbschema -d prulife -t valid_hub_log -ss ${TMPFILE} > /dev/null;
cat ${TMPFILE} >> ${LOGFILE}


echo "################### 4. valid_hub_stg  ##################" >> ${LOGFILE}
echo "--------------- Before Image valid_hub_stg-------------" >> ${LOGFILE}

dbschema -d prulife -t valid_hub_stg -ss ${TMPFILE} > /dev/null;
cat ${TMPFILE} >> ${LOGFILE}
wc -l ${TMPFILE}|read line_cnt dummy

if [ $line_cnt -gt 7 ]
then
    DROP_TABLE=" drop table valid_hub_stg ;"
    echo "table valid_hub_stg will be dropped then re-created" >> ${LOGFILE}
else
    DROP_TABLE=""
    echo "table valid_hub_stg will be created" >> ${LOGFILE}
fi
echo $DROP_TABLE
echo "--------------- Create table valid_hub_stg ----------------">> ${LOGFILE}
(
dbaccess prulife <<!EOF

$DROP_TABLE

create table "informix".valid_hub_stg
  (
        pol_no char(12) not null,
        prog_id char(30) not null,
        valid_rule_no smallint not null,
        para_key char(15) not null,
        para_value char(300)
  );

create unique index "informix".valid_hub_stg_idx1 on "informix".valid_hub_stg(pol_no, prog_id, valid_rule_no, para_key) ${INDEX_SPACE} ;

revoke all on "informix".valid_hub_stg from "public" as "informix";
grant all on "informix".valid_hub_stg to "prulife_all_access" as "informix";
update statistics for table "informix".valid_hub_stg;


!EOF
) >>${LOGFILE}  2>&1

echo "------------- After Image valid_hub_stg------------" >> ${LOGFILE}

dbschema -d prulife -t valid_hub_stg -ss ${TMPFILE} > /dev/null;
cat ${TMPFILE} >> ${LOGFILE}

echo "-----------------  Complete process --------------------" >> ${LOGFILE}
date >> ${LOGFILE}
chmod 666 ${LOGFILE}
cp -p ${LOGFILE} ${CHKPATH}
exit 0
