--valid_hub_map_main
        select * from valid_hub_map_main

        select * from valid_hub_map_sp

--sp_v1282_chk_vhis_sa
--How about VSPR, VFPR?
--1000, 7750 hard code?
--setup
        insert into valid_hub_map_main
        values (1282, "Specify", "lnb0230u", "VSP", "", "", "", "", today, "UT");
        insert into valid_hub_map_main
        values (1282, "Specify", "lnb0230u", "VFP", "", "", "", "", today, "UT");

        insert into valid_hub_map_sp
        values (1282, "P", "N", "sp_v1282_chk_vhis_sa", "Y", "N", today, "UT");

--UT
execute procedure sp_v1282_chk_vhis_sa("VHIS00010001", "", "", "PROP", "VSP", "N")
execute procedure sp_v1282_chk_vhis_sa("VHIS00010002", "", "", "PROP", "VFP", "N")
execute procedure sp_v1282_chk_vhis_sa("VHIS00010003", "", "", "PROP", "VFP", "N")

execute procedure sp_v1282_chk_vhis_sa("VHIS00010011", "", "", "PROP", "VSP", "N")
execute procedure sp_v1282_chk_vhis_sa("VHIS00010012", "", "", "PROP", "VFP", "N")
execute procedure sp_v1282_chk_vhis_sa("VHIS00010013", "", "", "PROP", "VFP", "N")

--sp_v1283_chk_vhis_bt_comb
--setup
        insert into valid_hub_map_main
        values (1283, "Specify", "lnb0230u", "VSP", "", "", "", "", today, "UT");
        insert into valid_hub_map_main
        values (1283, "Specify", "lnb0230u", "VFP", "", "", "", "", today, "UT");
        insert into valid_hub_map_main
        values (1283, "Specify", "lnb0230u", "VSPR", "", "", "", "", today, "UT");
        insert into valid_hub_map_main
        values (1283, "Specify", "lnb0230u", "VFPR", "", "", "", "", today, "UT");
        insert into valid_hub_map_sp
        values (1283, "B", "Y", "sp_v1283_chk_vhis_bt_comb", "Y", "N", today, "UT");
--ut
        execute procedure sp_v1283_chk_vhis_bt_comb("VHIS00010001", "", "", "PROP", "VSP", "N")
        execute procedure sp_v1283_chk_vhis_bt_comb("VHIS00010011", "", "", "PROP", "VSP", "Y")
        ;
        --[bt_pt_comb]
        unload to sp_v1283_chk_vhis_bt_comb.bt_pt_comb.dat
        select  * from bt_pt_comb
        where benf_cd in("VSP", "VSPR", "VFP", "VFPR")
        ;
        load from sp_v1283_chk_vhis_bt_comb.bt_pt_comb.dat
        insert into bt_pt_comb
        ;
        -[prop_person_hdr]
        insert into prop_person_hdr values("VHIS00010001", "L", "VHIS0001", "", "", "", "", "P", "", "");
        insert into prop_person_hdr values("VHIS00010002", "L", "VHIS0002", "", "", "", "", "P", "", "");
        insert into prop_person_hdr values("VHIS00010003", "L", "VHIS0003", "", "", "", "", "P", "", "");
        insert into prop_person_hdr values("VHIS00010011", "L", "VHIS0011", "", "", "", "", "P", "", "");
        insert into prop_person_hdr values("VHIS00010012", "L", "VHIS0012", "", "", "", "", "P", "", "");
        insert into prop_person_hdr values("VHIS00010013", "L", "VHIS0013", "", "", "", "", "P", "", "");

        unload to sp_v1283_chk_vhis_bt_comb.prop_person_hdr.dat
        select * from prop_person_hdr where prop_no >= "VHIS00010001"
        ;
        load from sp_v1283_chk_vhis_bt_comb.prop_person_hdr.dat
        insert intoprop_person_hdr
        ;
        --[cdb_mast]
        insert into cdb_mast(client_cd, dob) values ("VHIS0001", "2018-01-01");
        insert into cdb_mast(client_cd, dob) values ("VHIS0002", "2018-01-01");
        insert into cdb_mast(client_cd, dob) values ("VHIS0003", "2018-01-01");
        insert into cdb_mast(client_cd, dob) values ("VHIS0011", "2018-01-01");
        insert into cdb_mast(client_cd, dob) values ("VHIS0012", "2018-01-01");
        insert into cdb_mast(client_cd, dob) values ("VHIS0013", "2018-01-01");

        unload to sp_v1283_chk_vhis_bt_comb.cdb_mast.dat
        select * from cdb_mast where client_cd matches "VHIS*"
        ;
        --[prop_benf]
        insert into prop_benf(prop_no, benf_cd, incpt_dt, bt) values ("VHIS00010001", "VSP", "2019-01-01", "50");
        insert into prop_benf(prop_no, benf_cd, incpt_dt, bt) values ("VHIS00010002", "VFP", "2019-01-01", "99");
        insert into prop_benf(prop_no, benf_cd, incpt_dt, bt) values ("VHIS00010003", "VFPR", "2019-01-01", "99");

        insert into prop_benf(prop_no, benf_cd, incpt_dt, bt) values ("VHIS00010011", "VSP", "2034-01-01", "85");
        insert into prop_benf(prop_no, benf_cd, incpt_dt, bt) values ("VHIS00010012", "VFP", "2019-01-01", "99");
        insert into prop_benf(prop_no, benf_cd, incpt_dt, bt) values ("VHIS00010013", "VFPR", "2019-01-01", "99");
        unload to sp_v1283_chk_vhis_bt_comb.prop_benf.dat
        select * from prop_benf where prop_no matches "VHIS*"
        ;
        delete from prop_benf where prop_no matches "VHIS*"
        ;

--sp_v1284_chk_exceed_max_med_plan
--check is dynmiac or not
--not to specify the prod_cd or not?

--setup
        insert into valid_hub_map_main
        values (1284, "Specify", "lnb0230u", "", "", "", "", "", today, "UT");

        insert into valid_hub_map_sp
        values (1284, "P", "N", "sp_v1284_chk_exceed_max_med_plan", "Y", "N", today, "UT");

--sp_v1286_chk_vfp_benf_opt
--check is dynmiac or not
        insert into valid_hub_map_main
        values (1286, "Specify", "lnb0230u", "VFP", "", "", "", "", today, "UT");

        insert into valid_hub_map_main
        values (1286, "Specify", "lnb0230u", "VFPR", "", "", "", "", today, "UT");

        insert into valid_hub_map_sp
        values (1286, "B", "N", "sp_v1286_chk_vfp_benf_opt", "Y", "N", today, "UT");

--sp_v1288_chk_hkid_hkresid
--check is dynamic or not
         insert into valid_hub_map_main
        values (1288, "Specify", "lnb0230u", "VFPR", "", "", "", "", today, "UT");

        insert into valid_hub_map_sp
        values (1288, "P", "N", "sp_v1288_chk_hkid_hkresid", "Y", "N", today, "UT");

select * from message where msg_desc matches "Wrong*"

select * from message where msg_desc matches "SA*"

v081_chk_max_benf_sa

select * from message where msg_code in (5264, 8207)
select * from benf_extra_ctl where ctl_type = "VALID_SA"
   and fi_anb between from_value and to_value
v5264_chk_maxsa

select * from prod_ctl where ctl_type = "XBAS_SA"
select unique ctl_scale from benf_ctl where ctl_type = 'MAX_SA'
select * from prod_ctl where ctl_type matches "*SA*"
select * from

select pol_no, benf_amt from pol_benf
select * from pol_basic where pol_no = "000000917919"
select basic_sa from pol_basic where pol_no = "000000917919"
select * from pol_benf where pol_no = "000000917919"
select benf_amt from pol_benf where pol_no = "000000917919" 4500100.00

select prop_no, basic_sa, prod_cd from prop_basic
select pol_no, basic_sa, prod_cd from pol_basic
select pol_no, basic_sa,prod_cd, job_no from mvmt_pol_basic

select prop_no,incpt_dt, bt, pt, benf_cd from prop_benf
select pol_no,incpt_dt, bt, pt from pol_benf
select pol_no,incpt_dt, bt, pt,job_no from mvmt_pol_benf
select mvmt_no, job_no, * from mvmt_pol_benf
select * from bt_pt_comb

bt_pt_comb

select * from pol_benf
bt_pt_comb
select * from bt_pt_comb
bt_pt_comb.bt_type
