{
################################################################################
--
-- Procedure   : sp_chk_clm_ncb_period.sql
--
-- Description : Check if claim record exists in the NCB (No Claim Bonus) period
--
-- Input       : 1) Policy No.
--               2) Benefit Code
--               3) No Claim Period From Date
--               4) No Claim Period To Date
--
-- Output      : 1) Return Flag (1-claim record exists; 0-claim record not found)
--
-- Ver   Date          Auth.        MCN            Description
-- 000   11 Nov 2015   Windy        IT154428-01    Program Creation
-- 001   13 Sep 2017   David        IT172580-06    exclude Outpatient Surgery claim
-- 002   18 Oct 2017   Toto         IN00676283-03  Fix for NCB handling - Medicial repricing 2017
--                                                 Historial data handling for empty clm_hosp_reimbus.hosp_type
################################################################################
}

drop procedure "informix".sp_chk_clm_ncb_period;

create procedure "informix".sp_chk_clm_ncb_period(fi_pol_no        char(12),
                                                  fi_benf_cd       char(8),
                                                  fi_ncb_fr_dt     date,
                                                  fi_ncb_to_dt     date)
    returning smallint;

    define fo_clm_cnt   smallint;
    define f_clm_cnt    smallint;

    let fo_clm_cnt = 1;

    -- check pending claim records
    select count(*)
      into f_clm_cnt
      from clm_claims_mast
     where pol_no = fi_pol_no
       and benf_cd = fi_benf_cd
       and claim_sta = "O" -- Open
       and incid_dt >= fi_ncb_fr_dt
       and incid_dt <= fi_ncb_to_dt;

    if (f_clm_cnt > 0) then
        return fo_clm_cnt;
    end if

    -- check in-patient claim records
--v001s
--     select count(*)
--       into f_clm_cnt
--       from clm_claims_mast a, clm_hosp_period b
--      where a.pol_no   = b.pol_no
--        and a.claim_no = b.claims_no
--        and a.occ_no   = b.occ_no
--        and a.pol_no   = fi_pol_no
--        and a.benf_cd  = fi_benf_cd
--        and a.claim_ty = "HOSP" -- Hospital
--        and a.claim_sta in (
--                "G", -- On Exgratia
--                "A"  -- Admitted
--            )
--        and b.in_dt >= fi_ncb_fr_dt
--        and b.in_dt <= fi_ncb_to_dt;
    --Exisintg hosp_type in ("I: in-patient), "O: out-patient")
    --New hosp_type = "C": Outpatient Surgery claim
    --As Hosp_type in ("C", "I", "O"), all may exists record in clm_hosp_period with claim_ty = "HOSP"
    select count(*)
      into f_clm_cnt
      from clm_claims_mast a, clm_hosp_period b, clm_hosp_reimbus c
     where a.pol_no   = b.pol_no
       and a.claim_no = b.claims_no
       and a.occ_no   = b.occ_no
       and a.pol_no = c.pol_no
       and a.claim_no = c.claims_no
       and a.occ_no = c.occ_no
       and c.hosp_type = "I"
       and a.pol_no   = fi_pol_no
       and a.benf_cd  = fi_benf_cd
       and a.claim_ty = "HOSP" -- Hospital
       and a.claim_sta in (
               "G", -- On Exgratia
               "A"  -- Admitted
           )
       and ((b.in_dt is not null and b.in_dt >= fi_ncb_fr_dt and b.in_dt <= fi_ncb_to_dt) or
            (b.in_dt is null and c.in_date >= fi_ncb_fr_dt and c.in_date <= fi_ncb_to_dt));
--v001e

    if (f_clm_cnt > 0) then
        return fo_clm_cnt;
    end if

    -- check out-patient claim records
    select count(*)
      into f_clm_cnt
      from clm_claims_mast a, clm_hosp_reimbus b
     where a.pol_no   = b.pol_no
       and a.claim_no = b.claims_no
       and a.occ_no   = b.occ_no
       and a.pol_no   = fi_pol_no
       and a.benf_cd  = fi_benf_cd
       and a.claim_ty = "HOSP" -- Hospital
       and a.claim_sta in (
               "G", -- On Exgratia
               "A"  -- Admitted
           )
       and b.hosp_type = "O"
       and b.out_date >= fi_ncb_fr_dt
       and b.out_date <= fi_ncb_to_dt;

    if (f_clm_cnt > 0) then
        return fo_clm_cnt;
    end if

    -- check critical illness and death claim records
    select count(*)
      into f_clm_cnt
      from clm_claims_mast
     where pol_no = fi_pol_no
       and benf_cd = fi_benf_cd
       and claim_ty in ("MAJOR", "DEATH") -- Major and Death
       and claim_sta in (
               "G", -- On Exgratia
               "A"  -- Admitted
           )
       and incid_dt >= fi_ncb_fr_dt
       and incid_dt <= fi_ncb_to_dt;

    if (f_clm_cnt > 0) then
        return fo_clm_cnt;
    end if

--v002s
--Historial data handling for empty clm_hosp_reimbus.hosp_type
    select count(*)
      into f_clm_cnt
      from clm_claims_mast a, clm_hosp_period b, clm_hosp_reimbus c
     where a.pol_no   = b.pol_no
       and a.claim_no = b.claims_no
       and a.occ_no   = b.occ_no
       and a.pol_no = c.pol_no
       and a.claim_no = c.claims_no
       and a.occ_no = c.occ_no
       and (c.hosp_type is null or c.hosp_type = '')
       and a.pol_no   = fi_pol_no
       and a.benf_cd  = fi_benf_cd
       and a.claim_ty = "HOSP" -- Hospital
       and a.claim_sta in (
               "G", -- On Exgratia
               "A"  -- Admitted
           )
       and b.in_dt >= fi_ncb_fr_dt
       and b.in_dt <= fi_ncb_to_dt
       ;

    if (f_clm_cnt > 0) then
        return fo_clm_cnt;
    end if
    
--Handling for benefits without records in clm_hosp_reimbus table (LW & RHC)
    select count(*)
      into f_clm_cnt
      from clm_claims_mast a, clm_hosp_reimbus c
     where a.pol_no = c.pol_no
       and a.claim_no = c.claims_no
       and a.occ_no = c.occ_no
	   and a.pol_no   = fi_pol_no
       and a.benf_cd = fi_benf_cd
       and a.claim_ty = "HOSP" -- Hospital
       and a.claim_sta in (
               "G", -- On Exgratia
               "A"  -- Admitted
           );

    if f_clm_cnt = 0 then
        select count(*)
          into f_clm_cnt
          from clm_claims_mast a, clm_hosp_period b
         where a.pol_no   = b.pol_no
           and a.claim_no = b.claims_no
           and a.occ_no   = b.occ_no
           and a.pol_no   = fi_pol_no
           and a.benf_cd  = fi_benf_cd
           and a.claim_ty = "HOSP" -- Hospital
           and a.claim_sta in (
                   "G", -- On Exgratia
                   "A"  -- Admitted
               )
           and b.in_dt >= fi_ncb_fr_dt
           and b.in_dt <= fi_ncb_to_dt;

        if (f_clm_cnt > 0) then
            return fo_clm_cnt;
        end if
    end if 
--v002e

    let fo_clm_cnt = 0;

    return fo_clm_cnt;
end procedure;

update statistics for procedure "informix".sp_chk_clm_ncb_period;
