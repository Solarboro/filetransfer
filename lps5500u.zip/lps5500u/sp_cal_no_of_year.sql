--drop procedure sp_cal_no_of_year;
create procedure sp_cal_no_of_year(f_from_date date, f_to_date date) 
returning decimal(8,4);

    define fo_no_of_year                                        decimal(8,4);
    define f_date                                               date;

    let fo_no_of_year = 0;

    if f_to_date < f_from_date then
        return 0;
    end if

    let f_date = f_from_date;

    let fo_no_of_year = 0;

    while (add_month(f_date,12) - 1) < f_to_date
        let fo_no_of_year = fo_no_of_year + 1;
        let f_date = add_month(f_date,12);
    end while

    let fo_no_of_year = fo_no_of_year +
                        (f_to_date - f_date + 1) /
                        ((add_month(f_date,12) - f_date - 1) + 1);

    return fo_no_of_year;
end procedure;
