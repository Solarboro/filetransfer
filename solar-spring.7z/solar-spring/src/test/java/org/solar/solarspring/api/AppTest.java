package org.solar.solarspring.api;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.kie.api.KieBase;
import org.kie.api.runtime.KieSession;

import org.solar.solarspring.business.Student;
import org.solar.solarspring.enums.CountryEnum;
import org.solar.solarspring.model.FirstFact;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;


@RunWith(SpringRunner.class)
@SpringBootTest
class AppTest {


    @Autowired
    private KieBase kieBase;

    @Autowired
    private Student student;

    @Test
    void sayHalo() {

        FirstFact firstFact = new FirstFact();


        ArrayList<String> strings = new ArrayList<>();
        strings.add("st1");
        strings.add("st2");
        strings.add("solar");

        firstFact.setName("solar");
//        firstFact.setCe(CountryEnum.CHINA);
//        firstFact.setCe(CountryEnum.ENGLISH);
        firstFact.setCe(CountryEnum.AMERICAN);
        firstFact.setNames(strings);


        KieSession kieSession = kieBase.newKieSession();

        kieSession.insert(firstFact);
        kieSession.setGlobal("student", student);

        kieSession.fireAllRules();
        kieSession.dispose();


    }
}