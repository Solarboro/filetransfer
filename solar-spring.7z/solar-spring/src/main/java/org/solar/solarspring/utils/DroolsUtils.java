package org.solar.solarspring.utils;

public class DroolsUtils {
}
