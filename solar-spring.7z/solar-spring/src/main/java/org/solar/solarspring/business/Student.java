package org.solar.solarspring.business;

public interface Student {
    void sayhalo();
}
