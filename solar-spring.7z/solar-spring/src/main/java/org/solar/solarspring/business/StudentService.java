package org.solar.solarspring.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class StudentService implements Student {

    @Override
    public void sayhalo() {
        RestTemplate restTemplate = new RestTemplate();
        System.out.println(restTemplate.getForObject("https://www.baidu.com", String.class));
        System.out.println("Student Say helo");
    }
}
