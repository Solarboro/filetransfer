package org.solar.solarspring.model;

import lombok.Data;
import org.solar.solarspring.enums.CountryEnum;

import java.util.List;

@Data
public class FirstFact {
    private String name;

    private List<String> names;

    private CountryEnum ce;

}
