package org.solar.solarspring.enums;

public enum CountryEnum {
    CHINA,
    AMERICAN,
    ENGLISH
}
