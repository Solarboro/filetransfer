package org.solar.solarspring.model;

import lombok.Data;

@Data
public class Address {
    private String postCode;
    private String ad1;
    private String ad2;
}
