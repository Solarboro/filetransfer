/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.valid.req;

/**
 * Auto-generated: 2018-10-15 14:53:10
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class EnqInfo {

    private String proxyType;
    private String proxyValue;
    private String bankId;
    private String accountName;
    private String purposeCode;
    public void setProxyType(String proxyType) {
         this.proxyType = proxyType;
     }
     public String getProxyType() {
         return proxyType;
     }

    public void setProxyValue(String proxyValue) {
         this.proxyValue = proxyValue;
     }
     public String getProxyValue() {
         return proxyValue;
     }

    public void setBankId(String bankId) {
         this.bankId = bankId;
     }
     public String getBankId() {
         return bankId;
     }

    public void setAccountName(String accountName) {
         this.accountName = accountName;
     }
     public String getAccountName() {
         return accountName;
     }

    public void setPurposeCode(String purposeCode) {
         this.purposeCode = purposeCode;
     }
     public String getPurposeCode() {
         return purposeCode;
     }

}