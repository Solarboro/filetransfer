/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;


/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Header {

    private String msgId;
    private String orgId;
    private String timeStamp;
    public void setMsgId(String msgId) {
         this.msgId = msgId;
     }
     public String getMsgId() {
         return msgId;
     }

    public void setOrgId(String orgId) {
         this.orgId = orgId;
     }
     public String getOrgId() {
         return orgId;
     }

    public void setTimeStamp(String timeStamp) {
         this.timeStamp = timeStamp;
     }
     public String getTimeStamp() {
         return timeStamp;
     }

}