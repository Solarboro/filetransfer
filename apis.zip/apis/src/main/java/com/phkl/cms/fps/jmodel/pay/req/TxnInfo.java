/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;

/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class TxnInfo {

    private String customerReference;
    private String txnType;
    private String txnDate;
    private String txnCcy;
    private String txnAmount;
    private String purposeOfPayment;
    private SenderParty senderParty;
    private ReceivingParty receivingParty;
    private AdviseDelivery adviseDelivery;
    private RmtInf rmtInf;
    public void setCustomerReference(String customerReference) {
         this.customerReference = customerReference;
     }
     public String getCustomerReference() {
         return customerReference;
     }

    public void setTxnType(String txnType) {
         this.txnType = txnType;
     }
     public String getTxnType() {
         return txnType;
     }

    public void setTxnDate(String txnDate) {
         this.txnDate = txnDate;
     }
     public String getTxnDate() {
         return txnDate;
     }

    public void setTxnCcy(String txnCcy) {
         this.txnCcy = txnCcy;
     }
     public String getTxnCcy() {
         return txnCcy;
     }

    public void setTxnAmount(String txnAmount) {
         this.txnAmount = txnAmount;
     }
     public String getTxnAmount() {
         return txnAmount;
     }

    public void setPurposeOfPayment(String purposeOfPayment) {
         this.purposeOfPayment = purposeOfPayment;
     }
     public String getPurposeOfPayment() {
         return purposeOfPayment;
     }

    public void setSenderParty(SenderParty senderParty) {
         this.senderParty = senderParty;
     }
     public SenderParty getSenderParty() {
         return senderParty;
     }

    public void setReceivingParty(ReceivingParty receivingParty) {
         this.receivingParty = receivingParty;
     }
     public ReceivingParty getReceivingParty() {
         return receivingParty;
     }

    public void setAdviseDelivery(AdviseDelivery adviseDelivery) {
         this.adviseDelivery = adviseDelivery;
     }
     public AdviseDelivery getAdviseDelivery() {
         return adviseDelivery;
     }

    public void setRmtInf(RmtInf rmtInf) {
         this.rmtInf = rmtInf;
     }
     public RmtInf getRmtInf() {
         return rmtInf;
     }

}