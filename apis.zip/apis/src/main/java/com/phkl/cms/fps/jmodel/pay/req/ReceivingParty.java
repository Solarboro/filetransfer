/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;
import java.util.List;

/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ReceivingParty {

    private String name;
    private String bankId;
    private String bankCtryCode;
    private List<Addresses> addresses;
    private String proxyType;
    private String proxyValue;
    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setBankId(String bankId) {
         this.bankId = bankId;
     }
     public String getBankId() {
         return bankId;
     }

    public void setBankCtryCode(String bankCtryCode) {
         this.bankCtryCode = bankCtryCode;
     }
     public String getBankCtryCode() {
         return bankCtryCode;
     }

    public void setAddresses(List<Addresses> addresses) {
         this.addresses = addresses;
     }
     public List<Addresses> getAddresses() {
         return addresses;
     }

    public void setProxyType(String proxyType) {
         this.proxyType = proxyType;
     }
     public String getProxyType() {
         return proxyType;
     }
	public String getProxyValue() {
		return proxyValue;
	}
	public void setProxyValue(String proxyValue) {
		this.proxyValue = proxyValue;
	}
     

}