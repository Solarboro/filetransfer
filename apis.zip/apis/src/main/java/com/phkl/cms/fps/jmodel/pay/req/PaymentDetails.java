/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;

/**
 * Auto-generated: 2018-10-07 15:43:53
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PaymentDetails {

    private String paymentDetail;
    public void setPaymentDetail(String paymentDetail) {
         this.paymentDetail = paymentDetail;
     }
     public String getPaymentDetail() {
         return paymentDetail;
     }

}