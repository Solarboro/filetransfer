/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;

/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Emails {

    private String email;
    public void setEmail(String email) {
         this.email = email;
     }
     public String getEmail() {
         return email;
     }

}