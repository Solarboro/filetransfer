/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;

/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class SenderParty {

    private String name;
    private String accountNo;
    private String ddaRef;
    private String mandateId;
    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setAccountNo(String accountNo) {
         this.accountNo = accountNo;
     }
     public String getAccountNo() {
         return accountNo;
     }

    public void setDdaRef(String ddaRef) {
         this.ddaRef = ddaRef;
     }
     public String getDdaRef() {
         return ddaRef;
     }

    public void setMandateId(String mandateId) {
         this.mandateId = mandateId;
     }
     public String getMandateId() {
         return mandateId;
     }

}