/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;

/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Addresses {

    private String address;
    public void setAddress(String address) {
         this.address = address;
     }
     public String getAddress() {
         return address;
     }

}