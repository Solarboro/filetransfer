/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.req;

/**
 * Auto-generated: 2018-10-15 14:57:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class InvoiceDetails {

    private String invoice;
    public void setInvoice(String invoice) {
         this.invoice = invoice;
     }
     public String getInvoice() {
         return invoice;
     }

}