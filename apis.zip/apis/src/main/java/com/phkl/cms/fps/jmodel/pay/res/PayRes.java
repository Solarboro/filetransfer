/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.pay.res;

/**
 * Auto-generated: 2018-10-15 14:57:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PayRes {

    private Header header;
    private TxnResponse txnResponse;
    public void setHeader(Header header) {
         this.header = header;
     }
     public Header getHeader() {
         return header;
     }

    public void setTxnResponse(TxnResponse txnResponse) {
         this.txnResponse = txnResponse;
     }
     public TxnResponse getTxnResponse() {
         return txnResponse;
     }

}