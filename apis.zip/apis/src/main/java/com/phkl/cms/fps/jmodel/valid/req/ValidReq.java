/**
  * Copyright 2018 bejson.com 
  */
package com.phkl.cms.fps.jmodel.valid.req;

/**
 * Auto-generated: 2018-10-15 14:53:10
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ValidReq {

    private Header header;
    private EnqInfo enqInfo;
    public void setHeader(Header header) {
         this.header = header;
     }
     public Header getHeader() {
         return header;
     }

    public void setEnqInfo(EnqInfo enqInfo) {
         this.enqInfo = enqInfo;
     }
     public EnqInfo getEnqInfo() {
         return enqInfo;
     }

}