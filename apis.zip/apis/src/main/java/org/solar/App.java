package org.solar;

import org.solar.controller.Index;
import org.solar.controller.ThrowErrorHandler;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import org.solar.controller.SslClientHttpRequestFactory;

@ComponentScan(basePackageClasses=Index.class)
@EnableAutoConfiguration
public class App {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(App.class, args);
	}
	
	@Bean
	public RestTemplate restTemplate(ClientHttpRequestFactory factory) {
		RestTemplate restt = new RestTemplate(factory);
		restt.setErrorHandler(new ThrowErrorHandler());
		return restt;
	}
 
	@Bean
	public ClientHttpRequestFactory simpleClientHttpRequestFactory() {
		SslClientHttpRequestFactory  factory = new SslClientHttpRequestFactory();
		factory.setReadTimeout(90000);
		factory.setConnectTimeout(15000);
		return factory;
	}
}
