package org.solar.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.phkl.cms.fps.jmodel.pay.req.PayReq;
import com.phkl.cms.fps.jmodel.pay.res.PayRes;
import com.phkl.cms.fps.jmodel.pay.res.TxnResponse;
import com.phkl.cms.fps.jmodel.valid.req.EnqInfo;
import com.phkl.cms.fps.jmodel.valid.req.Header;
import com.phkl.cms.fps.jmodel.valid.req.ValidReq;
import com.phkl.cms.fps.jmodel.valid.res.EnqResponse;
import com.phkl.cms.fps.jmodel.valid.res.ValidRes;


@RestController
public class Index {
	@Autowired
	RestTemplate httpsRestTemplate;

	@RequestMapping(value="/script",method=RequestMethod.GET, produces="application/json")
	public String testScript(){
		return "Welocom";
	}
	
	@RequestMapping(value="/",method=RequestMethod.GET, produces="application/json")
//	public HttpEntity<ValidReq> homePage(){
	public String homePage(){
		
//		RestTemplate httpsRestTemplate = new RestTemplate();
		HttpEntity<ValidReq> requestEntity;
		MultiValueMap<String, String> headers;
		ResponseEntity<String> responseEntity;
		ValidRes validRes;
		ValidReq validreq = new ValidReq();
		EnqInfo enqInfo = new EnqInfo();
		Header header = new Header();
		

		
		//Header
		headers= new LinkedMultiValueMap<String, String>();
		
//		headers.add("POST", "/rapid/enquiry/v1/cashk/verification HTTP/1.1");
//		headers.add("Host","Dummy Host");
		headers.add("apiKey", "l7xx8ce07690a03e4497930f6a3cd46a9842");
//		headers.add("KeyId", "Dummy KeyId");
//		headers.add("ORG_ID", "HKPRUH");
//		headers.add("Accept", "application/json");
//		headers.add("Content-Type", "application/json");
//		headers.add("Content-Length", "728");
		
		//Body
		header.setMsgId("HKO82F2449701656579");
		header.setOrgId("0123");
		header.setTimeStamp("2018-04-12T10:53:29.996");
		header.setBankCtryCode("HK");
		enqInfo.setProxyType("E");
		enqInfo.setProxyValue("HKD645329791@dbs.com");
		enqInfo.setBankId("016");
		enqInfo.setBankId("SpringBoot Application");
		validreq.setHeader(header);
		validreq.setEnqInfo(enqInfo);
		
		//RequestEntity
//		requestEntity = new HttpEntity<ValidReq>(validreq, headers);
		requestEntity = new HttpEntity<ValidReq>(headers);
		

		System.out.println("Start ==================");
		try{
		responseEntity = httpsRestTemplate.exchange("https://apidev.prudential.com.hk/api/fps-proxy-enquiry", 
				HttpMethod.POST, 
				requestEntity, 
				String.class);
		}
		catch (RestClientException e){
			e.printStackTrace();
			
			System.out.println(e.getMessage());
		}
		
//		validRes = responseEntity.getBody();
		
		return "Done.";
		
	}
	
	@RequestMapping(value="/get",method=RequestMethod.GET)
//	public HttpEntity<ValidReq> homePage(){
	public String requestGet(){
		
		return httpsRestTemplate.getForObject("https://apidev.prudential.com.hk/helloworld", String.class);
		
	}
	
	@RequestMapping(value="/payment", method=RequestMethod.POST)
	public PayRes payment(@RequestBody PayReq payReq){
		PayRes pr = new PayRes();
		
		com.phkl.cms.fps.jmodel.pay.res.Header header = new com.phkl.cms.fps.jmodel.pay.res.Header();
		TxnResponse txnResponse = new TxnResponse();
		
		SimpleDateFormat DateFormatToday = new SimpleDateFormat("yyyyMMdd");
		
		header.setMsgId(payReq.getHeader().getMsgId());
		header.setTimeStamp("TimeStamp Dummy");
		
		if(payReq.getHeader().getMsgId().equals(DateFormatToday.format(new Date()) + "002")){
			txnResponse.setCustomerReference("Dummy CustomerReference");
			txnResponse.setTxnRefId("Dummy RefId");
			txnResponse.setBankReference("Dummy BankReference");
			txnResponse.setTxnType("GPP");
			txnResponse.setTxnStatus("RJCT");
			txnResponse.setTxnRejectCode("1160");
			txnResponse.setTxnStatusDescription("Payer/payee account is closed");
			txnResponse.setTxnSettlementAmt("Dummy SettlementAmt");
			txnResponse.setTxnSettlementDt("Dummy SettlementDt");
			
		}
		else{
			txnResponse.setCustomerReference("Dummy CustomerReference");
			txnResponse.setTxnRefId("Dummy RefId");
			txnResponse.setBankReference("Dummy BankReference");
			txnResponse.setTxnType("GPP");
			txnResponse.setTxnStatus("ACTC");
			txnResponse.setTxnRejectCode("");
			txnResponse.setTxnStatusDescription("Success");
			txnResponse.setTxnSettlementAmt("Dummy SettlementAmt");
			txnResponse.setTxnSettlementDt("Dummy SettlementDt");
			
		}
		
		
		pr.setHeader(header);
		pr.setTxnResponse(txnResponse);
		
		
		return pr;
		
	}
	
	@RequestMapping(value="/verification", method=RequestMethod.POST)
	public ValidRes verification(@RequestBody ValidReq validReq){
		ValidRes vr = new ValidRes();
		
		com.phkl.cms.fps.jmodel.valid.res.Header header =new com.phkl.cms.fps.jmodel.valid.res.Header();
		EnqResponse enqResponse = new EnqResponse();
		
		SimpleDateFormat DateFormatToday = new SimpleDateFormat("yyyyMMdd");
		
		header.setMsgId(validReq.getHeader().getMsgId());
		header.setOrgId(validReq.getHeader().getOrgId());
		header.setTimeStamp("TimeStamp Dummy");
		
		
		if (validReq.getHeader().getMsgId().equals(DateFormatToday.format(new Date()) + "001")){
			enqResponse.setTxnRefId("Dummy ID");
			enqResponse.setProxyType(validReq.getEnqInfo().getProxyType());
			enqResponse.setProxyValue(validReq.getEnqInfo().getProxyValue());
			enqResponse.setRespStatus("RJCT");
			enqResponse.setRespStatusDescription("Validation Error");
			enqResponse.setRespRejectCode("I999");
			enqResponse.setAccountName(validReq.getEnqInfo().getAccountName());
			enqResponse.setDispNameEn("Dummy dispNameEn");
			enqResponse.setDispNameZh("Dummy dispNameZh");
			
		}
		else{
			enqResponse.setTxnRefId("Dummy ID");
			enqResponse.setProxyType(validReq.getEnqInfo().getProxyType());
			enqResponse.setProxyValue(validReq.getEnqInfo().getProxyValue());
			enqResponse.setRespStatus("ACTC");
			enqResponse.setRespStatusDescription("Matched");
			enqResponse.setRespRejectCode("");
			enqResponse.setAccountName(validReq.getEnqInfo().getAccountName());
			enqResponse.setDispNameEn("Dummy dispNameEn");
			enqResponse.setDispNameZh("Dummy dispNameZh");
			
		}
		
		vr.setHeader(header);
		vr.setEnqResponse(enqResponse);
		return vr;
		
	}
}
